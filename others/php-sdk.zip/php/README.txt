
本SDK是为PHP语言调用由CSB(云服务总线)发布出来的HTTP服务。

本SDK包含两个PHP文件
1. http-caller.php 提供了HttpCaller类，里面定义了一系列的调用HTTP服务的方法
2. http-caller-samples.php 是一个调用示范文件，向使用者展示如何使用HttpCaller类


